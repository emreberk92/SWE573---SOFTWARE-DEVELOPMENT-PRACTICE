# SWE573 SOFTWARE DEVELOPMENT PRACTICE 
Repository to be used during the lecture "SWE-573 Software Development Practice".
## Objective
The contect of this repository is filled up with the weekly tasks assgined by the instructor. Hereby, the main features of github will be covered for software development. 
## URL to Repository 
Please use the following command to open this repository: <br/>
`git clone https://github.com/emreberk92/SWE573---SOFTWARE-DEVELOPMENT-PRACTICE.git`
